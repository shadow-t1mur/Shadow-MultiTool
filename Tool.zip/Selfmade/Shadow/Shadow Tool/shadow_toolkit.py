from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich import box
import time, os, socket, random, subprocess, requests

console = Console()

# Helper
clear = lambda: os.system("cls" if os.name == "nt" else "clear")

def animated_text(text, delay=0.005):
    for char in text:
        print(char, end='', flush=True)
        time.sleep(delay)
    print()

def gradient_text(text):
    result = Text()
    length = len(text)
    for i, char in enumerate(text):
        r = 255
        g = int(255 - (255 * i / length))
        b = int(255 - (255 * i / length))
        result.append(char, style=f"rgb({r},{g},{b})")
    return result

# Startbildschirm
start_ascii = '''⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⣿⠲⠤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⣸⡏⠀⠀⠀⠉⠳⢄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⣿⠀⠀⠀⠀⠀⠀⠀⠉⠲⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⢰⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠲⣄⠀⠀⠀⡰⠋⢙⣿⣦⡀⠀⠀⠀⠀⠀
⠸⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣙⣦⣮⣤⡀⣸⣿⣿⣿⣆⠀⠀⠀⠀
⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⣿⣿⣿⠀⣿⢟⣫⠟⠋⠀⠀⠀⠀
⠀⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⣿⣷⣷⣿⡁⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⢸⣿⣿⣧⣿⣿⣆⠙⢆⡀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢾⣿⣤⣿⣿⣿⡟⠹⣿⣿⣿⣿⣷⡀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣧⣴⣿⣿⣿⣿⠏⢧⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠀⠈⢳⡀                    ████████╗    ██╗    ███╗   ███╗    ██╗   ██╗    ██████╗     
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⡏⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⢳                    ╚══██╔══╝    ██║    ████╗ ████║    ██║   ██║    ██╔══██╗    
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⢀⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀                       ██║       ██║    ██╔████╔██║    ██║   ██║    ██████╔╝    
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡇⠸⣿⣿⣿⣿⣿⣿⣿⣿⠏⠀⠀⠀⠀⠀⠀                       ██║       ██║    ██║╚██╔╝██║    ██║   ██║    ██╔══██╗    
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡇⠀⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀                       ██║       ██║    ██║ ╚═╝ ██║    ╚██████╔╝    ██║  ██║    
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⡇⢠⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀                       ╚═╝       ╚═╝    ╚═╝     ╚═╝     ╚═════╝     ╚═╝  ╚═╝    
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠃⢸⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣼⢸⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣾⣿⢸⣿⣿⣿⣿⣿⣿⣿⣿⡄⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⣿⣿⣾⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⢀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠛⠻⠿⣿⣿⣿⡿⠿⠿⠿⠿⠿⢿⣿⣿⠏
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀'''
def start_screen():
    clear()
    console.print(Text(start_ascii, style="bold red"))
    console.print(gradient_text("\nSHADOW TOOLKIT MADE BY T I M U R\n"))
    input("[ENTER] Starten...")

def banner():
    art = '''

                   ░▒▓███████▓▒░▒▓█▓▒░░▒▓█▓▒░░▒▓██████▓▒░░▒▓███████▓▒░ ░▒▓██████▓▒░░▒▓█▓▒░░▒▓█▓▒░░▒▓█▓▒░ 
                  ░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░░▒▓█▓▒░ 
                  ░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░░▒▓█▓▒░ 
                   ░▒▓██████▓▒░░▒▓████████▓▒░▒▓████████▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░░▒▓█▓▒░ 
                         ░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░░▒▓█▓▒░ 
                         ░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░░▒▓█▓▒░ 
                  ░▒▓███████▓▒░░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓███████▓▒░ ░▒▓██████▓▒░ ░▒▓█████████████▓▒░
'''
    console.print(gradient_text(art))

def geolocate_ip():
    ip = input("Enter IP: ")
    try:
        res = requests.get(f"http://ipinfo.io/{ip}/json")
        print("\n" + res.text)
    except:
        print("[-] Fehler beim Abrufen der IP.")
    input("\n[ENTER] zurück zum Menü.")

def tracedns():
    ip = input("Enter IP: ")
    try:
        result = socket.gethostbyaddr(ip)
        print(f"\nDomain Name: {result[0]}")
    except:
        print("[-] Keine DNS-Info gefunden.")
    input("\n[ENTER] zurück zum Menü.")

def port_scan():
    ip = input("IP Address: ")
    ports = input("Ports (z.B. 21, 22, 80, 53, 67, 68, 80, 443, 1900, 5353, 137, 138, 139, 445, 1812, 554): ").split(",")
    print()
    for port in ports:
        try:
            s = socket.socket()
            s.settimeout(0.5)
            s.connect((ip.strip(), int(port)))
            print(f"[+] Port {port} offen")
            s.close()
        except:
            print(f"[-] Port {port} geschlossen")
    input("\n[ENTER] zurück zum Menü.")

def ddos():
    target = input("Ziel (Domain oder IP): ")
    print(f"\n Sende Pakete an {target}...\n")
    for i in range(1, 10000):  # 10000 Pakete
        print(f" #{i} Packets an {target} mit dem Port [21] gesendet !")
        time.sleep(0.05)  # kürzere Pause für schnellere Simulation
    input("\n[ENTER] zurück zum Menü.")

def nitro_generator():
    print("\nGeneriere 1000 Discord Nitro Codes:\n")
    for _ in range(1000):
        code = ''.join(random.choices('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', k=16))
        print(f"https://discord.gift/{code} [False]")
        time.sleep(0.3)
    input("\n[ENTER] zurück zum Menü.")

def mac_address():
    ip = input("Enter IP: ")
    print(f"\nPinge {ip} an...")
    os.system(f"ping -n 1 {ip} >nul")
    try:
        output = subprocess.check_output("arp -a", shell=True).decode()
        for line in output.splitlines():
            if ip in line:
                mac = line.split()[1]
                print(f"\nMAC-Adresse: {mac.upper()}")
                break
        else:
            print("[-] Keine MAC-Adresse gefunden.")
    except:
        print("[-] Fehler beim Auslesen der ARP-Tabelle.")
    input("\n[ENTER] zurück zum Menü.")

def arpspoof():
    ip = input("Ziel-IP für ARP Spoof: ")
    print(f"\nStarte ARP Spoof auf {ip}...\n")
    for i in range(1, 6):
        print(f"[+] Sende gefälschtes ARP-Paket #{i}...")
        time.sleep(0.5)
    print("\n [BEENDET]")
    input("\n[ENTER] zurück zum Menü.")

def rpc_dump():
    ip = input("Ziel-IP: ")
    print(f"\n RPC Dump von {ip}...\n")
    print("Hostname: WIN-" + ''.join(random.choices("ABCDEF0123456789", k=8)))
    print("OS: Windows 10 Pro x64")
    print("MAC: 00-1A-2B-3C-4D-5E")
    print("UUID: " + ''.join(random.choices("abcdef0123456789", k=8)) + "-" + ''.join(random.choices("abcdef0123456789", k=4)))
    input("\n[ENTER] zurück zum Menü.")

def main_menu():
    while True:
        clear()
        banner()
        console.print(Panel(gradient_text("""
        [IP]
   1) IP Lookup 
   2) DDoS
   3) Port Scan
   4) MAC Addresse Verfolgen

       [System]
   5) RPC Dump
   6) Verlassen

      [Browser]
   7) DNS Verfolgen 
   8) ARP Spoof
   
      [Discord]
   9) Nitro Generator 
"""), title="[ SHADOW TOOLKIT ]", box=box.DOUBLE))

        choice = input("Eingabe...")

        if choice == "1":
            geolocate_ip()
        elif choice == "7":
            tracedns()
        elif choice == "3":
            port_scan()
        elif choice == "2":
            ddos()
        elif choice == "9":
            nitro_generator()
        elif choice == "4":
            mac_address()
        elif choice == "8":
            arpspoof()
        elif choice == "6":
            print("\nExiting... Bye!")
            break
        else:
            print("Ungültige Auswahl!")
            time.sleep(1)

if __name__ == "__main__":
    start_screen()
    main_menu()
