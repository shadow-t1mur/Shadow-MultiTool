**IP'S + Angaben**



**Ben   95.90.253.43**

Name             Benneto

Nachname         Unknown

Land             Germany

Stadt            Hamburg

Staat            Hamburg

ZeitZone         Europa/Berlin

System           Windows 11

GPU              Geforce RTX 3050

ScreenSize       1440 x 1080

Hz               60

Browser:         Chrome

AdBlocker:       Nein





**Benno             77.235.183.70**

Name             Maxim

Land             Deutschland

Stadt            Mildenau

Staat            Sachsen

ZeitZone         Europa/Berlin

System           Windows 11

ScreenSize       1920x1080

**Telefon Nummer     +49 163  3959344**

Browser          Chrome

AdBlocker        Ja 





**Blendi           93.118.28.186**

Land             Deutschland

Stadt            Hemmingen

Staat            Baden Wüttenberg

ZeitZone         Germany/Berlin

System           Windows 11

Wlan Anbieter    Fritz Box! / Telekom

ScreenSize       1920x1080

**Telefon Nummer     +49 170 8961627**

Browser          Microsoft Edge

Ad Blocker       Ja

**Bild             https://i.postimg.cc/yYXZbHwY/Blendi.png**





**IP               95.91.217.548**

Name             Cain

Nachname         Röder

Land             Deutschland

Stadt            Wissen

Staat            Rheinland-Phalz

ZeitZone         Europa/Berlin

System           Windows 11

Wlan Anbieter    Unknown

ScreenSize       1920x1080

**Telefon Nummer     +49 173 2658544**

Browser          Chrome

Ad Blocker       Ja





**IP:              95.91.181.166**

Name             Leo

Nachname         Vilmos

Land             Deutschland

Stadt            Berlin

Staat            Berlin

ZeitZone         Europa/Berlin

System           Windows 11

Wlan Anbieter    Unknown

ScreenSize       1920x1080

**Telephone Number:   +49 176 92163654**

Browser          Chrome

AdBlocker        Ja

**Picture 1        https://i.postimg.cc/BbfXbJpZ/Lucio-1.jpg**

**Picture 2        https://i.postimg.cc/fy7k01qc/Lucio-2.png**

**Discord          https://i.postimg.cc/5N0MzZrf/Screenshot-2025-05-06-225851.png**





**Discord        arne\_fo\_2012\_72011**

**IP Address     87.179.107.29**

Datum/Zeit	     16.9.2025, 18:16:28 Uhr

Land             Deutschland, Nienburg

ZeitZone      	 Europa/Berlin

User Time	     Mitteleuropäische Sommerzeit

Sprache 	     Deutsch

Ad Blocker	     Nein

Screen Size	     414 x 896 @ 30Hz

Farb Schema	     Hell

GPU	             Apple GPU

Browser   	     Mobile Safari

System    	     iOS 18.6.2

Gerät	         Apple iPhone

Wlan	         Deutsche Telekom AG



**Discord        emre0542sk**

**IP Address	77.183.104.198**

Zeit            20.09.2025 08:46:56 Uhr

Land            Deutschland, Berlin

ZeitZone	    Europe/Berlin GMT+2

Sprache         Deutsch

Ad Blocker	    Nein

Screen Size   	390 x 844 @ 60Hz

FarbSchema   	Hell

HDR Bildschirm	Nein

GPU	            Apple GPU

Browser 	    Mobile Safari 

System       	iOS 18.6

Gerät	        Apple iPhone



Name            Patric 

Nachname        Spiwak 

Adresse         Unknown

Arbeit          Hoppe Gartenbau

Handy           Samsung S23
 
Laptop          Asus

System          Windows11

Email           spiwak233@gmail.com

**Telefon Nummer  +49 176 20919905**

Snap            spiwak233

TikTok          aruxos233

**Bild 1          https://i.postimg.cc/4yHs6WSS/sns.jpg**

**Bild 2          https://i.postimg.cc/k5MVQdvm/dnd.jpg**

**Bild 3          https://i.postimg.cc/jj9sDVgY/fnf.jpg**



**Private IP   	  93.233.74.54**

Name            Steven

Nachname        Unknown

Land            Deutschland, Detmold

ZeitZone 	    Europa/Berlin

Sprache    	    Deutschland

Ad Blocker	    Nein

Screen Size  	320 x 658 @ 59Hz

Farb Schema     Dunkel

**Öffentliche IP  192.168.2.34**

Browser	        Chrome Mobile

System	        Android 10

Wlan Anbieter   Deutsche Telekom AG

**Bild 1          https://i.postimg.cc/Gpwmhn9S/gdrgdrgdr.jpg**

**Bild 2          https://i.postimg.cc/4dX4Vv6j/rtdghdrtg.jpg**

**Bild 3          https://i.postimg.cc/WpWpqkhG/jzjzgjg.jpg**

**Audio           https://video.zig.ht/v/s9atae3jvty2jqt1e1oli**



Name            Till

Nachname        Unknown

**IP Address	    47.64.50.74**

Land            Deutschland, Eschborn 

ZeitZone	    Europa/Berlin

Sprache	        Deutsch

Ad Blocker	    Nein

Screen Size	    412 x 915 @ 55Hz

Farb Schema  	Hell

**Öffentliche IP	100.79.114.26**

Browser	        Samsung Browser
 
System	        Android 10

Wlan Anbieter   Vodafone GmbH

**Bild            https://i.postimg.cc/CMZVR6kw/Whats-App-Bild-2025-10-28-um-21-31-39-676cd37d.jpg**